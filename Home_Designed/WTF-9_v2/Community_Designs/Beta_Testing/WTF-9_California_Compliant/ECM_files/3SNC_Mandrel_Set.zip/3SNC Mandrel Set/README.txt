>Author<
3socksandcrocs

>Version<
0.1.4

>Description<
This mandrel set is based on Ivanthetroll's mandrel, I had no hand in creating the original model.
I have simply changed the length, and added a way to align and connect the segments.
The required 3mm rod for joining will be leftovers from building your firing pin in many designs.

For a 267mm/10.5" barrel use one chamber end and one fitting end. This has been tested and successfully rifled a barrel. The test barrel has
fired over 350 rounds.

For a 409mm/16.1" barrel use one 141mm center section with the chamber and fitting ends. Untested.

For a 500mm/19.7" barrel use 2 116mm center sections with the chamber and fitting ends. This is still being tested as of this version, but has already been used to rifle a barrel.


I have also included mandrels sized at 99% diameter.

For print settings and ECM instructions please refer to Ivanthetroll's ECM guide in the ButWhatAbout package.


>Variances from Ivan's guide<

Test barrel was bored and rifled at 9.5A. Chambering done at 7.5A, as normal.

Pump was run unimpeded on a 5 amp power supply for boring. Flow was limited (smaller PSU, or clamp high pressure line) during rifling and chambering.

Barrel flipped end for end at least every 30 minutes during boring to ensure even cutting. Just do this when measuring.

When rifling longer barrels avoid cutting for more than 5 minutes without allowing sludge to clear. Turning off the cutting PSU while running the pump for 30 seconds
seemed to keep the mandrel clear of sludge. This is especially important during the beginning of the 500mm barrel.

Expect boring and rifling time to increase with barrel length. Check progress regularly to avoid overshooting.


>Assembly<
Wires are soldered in using the same method. 
Use a 20mm piece of 3mm rod to join the pieces. I simply heated the rod with
a solder gun, though I'm sure epoxy would work as well. Be careful not to overheat the mandrel and ruin it. Be sure the rod can be inserted BEFORE heating, if the hole is too
tight you will surely squish the mandrel and ruin it.


This is by no means a definitive guide. I have successfully used this, but additional testing would verify repeatability. 
Please post your results on det_disp keybase should you decide to use this set up.